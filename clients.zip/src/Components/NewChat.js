import React, { useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import ScrollToBottom from "react-scroll-to-bottom";
import "./NewChat.css";
import axios from "axios";
import { useState } from "react";
import { io } from "socket.io-client";
import moment from "moment"

const socket = io("http://localhost:3500");
function NewChat() {
  const user = JSON.parse(localStorage.getItem("user"));

  const [callConversation, setCallConversation] = useState([]);
  const [allMessage, setAllMessage] = useState([]);
  const [chat, setChat] = useState("");
  const [createConversation, setCreateConversation] = useState("");
  const [currentChat, setCurrentChat] = useState(null);
  const [member1, setMember1] = useState("");
  const [member2, setMember2] = useState("");
  const[isTyping , setIsTyping] = useState([])
  const [data, setData] = useState([]);

  useEffect(() => {
    socket.emit("join chat", user.id);
    socket.on("receive message", (message) => {
      setAllMessage([...allMessage, message]);
      // console.log(message + "hdjs");
    });

    socket.on("typing", (data) => {
      // console.log("hi typing:",data)
     setIsTyping(data)
     
     console.log("type ho rha", isTyping)
    });
    // socket.on("userOnline", (userOnline) => {
    //   console.log("how many online user", userOnline);
    // });
  }, []);

  // send Message
  const sendMessage = (e) => {
    e.preventDefault();
    const getId = {
      usersId: user?.id,
      conversationId: currentChat?.id,
    };

    axios
      .post("http://localhost:3500/sendMessage", {
        contents: chat,
        conversationId: getId.conversationId,
        senderId: getId.usersId,
      })
      .then((res) => {
        //console.log(res);
        setAllMessage([...allMessage, res.data.newMessage]);
        socket.emit("send message", res.data.newMessage);
        setChat("");
      })
      .catch((err) => console.log(err));
  };

  // show chat
  const showChat = async (secondMem) => {
    //console.log(secondMem.id);
    const ifConvExist = callConversation?.find((c) => {
      // console.log("gh:", c);
      return (
        (c.chatapp_userModels[0].id === secondMem.id &&
          c.chatapp_userModels[1].id === user.id) ||
        (c.chatapp_userModels[1].id === secondMem.id &&
          c.chatapp_userModels[0].id === user.id)
      );
    });
    //console.log(ifConvExist);
    if (ifConvExist) {
      setCurrentChat(ifConvExist);
    } else {
      const res = await axios.post("http://localhost:3500/createConversation", {
        member1: user.id,
        member2: secondMem.id,
      });
      //console.log(res.data, "c");
      getConversation();
    }
  };

  // get Conversation
  const getConversation = () => {
    axios
      .get(`http://localhost:3500/conversation/${user.id}`)
      .then((response) => {
        //console.log("Conversation : ", response.data.conversations);
        setCallConversation(response.data.conversations);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  useEffect(() => {
    getConversation();
  }, []);

  // getUser
  const getUsers = () => {
    axios
      .get("http://localhost:3500/getUsers")
      .then((response) => {
        //console.log("users:", response.data);
        setData(response.data);
      })
      .catch((err) => console.log(err));
  };

  useEffect(() => {
    getUsers();
  }, []);

  // how to get message
  const getMessage = () => {
    axios
      .get(`http://localhost:3500/messages/${currentChat?.id}`)
      .then((response) => {
        console.log("message:", response.data.messages);
        setAllMessage(response.data.messages);
      })
      .catch((err) => console.log(err));
  };

  useEffect(() => {
    getMessage();
  }, [currentChat]);

  const inputHandler =(e)=>{
      if (e.target.value){
          socket.emit("sendTyping",{currentChat ,user})
      }
    setChat(e.target.value)
  }

  return (
    <div>
      <section style={{ backgroundColor: "white" }}>
        <div class="container py-2">
          <div class="row">
            
            <div class="col-md-12">
            <div class="card" id="chat3" style={{ borderRadius: "20px;" }}>
            <div class="card-body">
            <div>
            <h3 >
              Giri<span style={{ color: "#0059" }}>Bot</span>
            </h3>
            </div>
                  <div class="row">
                    <div class="col-md-6 col-lg-5 col-xl-4 mb-4 mb-md-0 list">
                      <div class="p-3" >
                      
                        {data.length > 0 &&
                          data.map(
                            (dataObj, index) =>
                              dataObj.id === user.id && (
                                <h4 > Welcome <span style={{color:"#3499"}}>{dataObj.name}</span> </h4>
                              )
                          )}
                        <div
                          data-mdb-perfect-scrollbar="true"
                          style={{ position: "relative", height: "400px" }}
                        >
                          {data.length > 0 &&
                            data.map(
                              (dataObj, index) =>
                                dataObj.id !== user.id && (
                                  <ul class="list-unstyled mb-0">
                                    <li class="p-2 border-bottom">
                                      <a
                                        href="#!"
                                        class="d-flex justify-content-between"
                                      >
                                        <div class="d-flex flex-row">
                                          <div>
                                            <img
                                              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQpcLzYU8SsybUPTpqpI01wbVK1Ysqi5FU98w&usqp=CAU"
                                              alt="avatar"
                                              class="d-flex align-self-center me-3"
                                              width="40"
                                              style={{borderRadius:"50%"}}
                                            />
                                            <span class="badge bg-success badge-dot"></span>
                                          </div>
                                          <div class="pt-1">
                                            <h5
                                              onClick={() => showChat(dataObj)}
                                              class="fw-bold mb-0"
                                            >
                                              {dataObj.name}
                                            </h5>
                                          </div>
                                        </div>
                                        <div class="pt-1">
                                          <p class="small text-muted mb-1">
                                          {moment(dataObj.createdAt).format('h:mm a ')}
                                          </p>
                                          <span class="badge bg-danger rounded-pill float-end">
                                            3
                                          </span>
                                        </div>
                                      </a>
                                    </li>
                                  </ul>
                                )
                            )}
                        </div>
                      </div>
                    </div>

                  
                      <div class="col-md-6 col-lg-7 col-xl-8 message">
                        <div class="card-body">
                          <div class="message">
                            {currentChat && (
                              <div class="message-content">
                                <h4 style={{backgroundColor:"white", borderRadius:"20px"}}>
                                  {
                                    currentChat?.chatapp_userModels.find(
                                      (dataObj) => {
                                        return dataObj.id !== user.id;
                                      }
                                    ).name
                                  }
                                </h4>
                              </div>
                            )}
                          </div>
                        </div>
                        <div
                          class="pt-3 pe-3"
                          data-mdb-perfect-scrollbar="true"
                          style={{ position: "relative", height: "400px" ,overflow:"auto"}}
                        >
                        
                          <div >
                            {allMessage.length > 0 &&
                              allMessage.map((dt, index) => {
                                return (
                                  <div
                                    class="message-content"
                                    style={{ position: "relative" }}
                                  >
                                    <div
                                      style={{
                                        backgroundColor:
                                          dt.senderId === user.id
                                            ? " RGB( 18, 140, 126)"
                                            : "black",
                                        color:
                                          dt.senderId === user.id
                                            ? "white"
                                            : "white",
                                        marginLeft:
                                          dt.senderId === user.id
                                            ? "auto"
                                            : null,
                                        marginRight:
                                          dt.senderId !== user.id
                                            ? "auto"
                                            : null,
                                        // border: "1px solid",
                                        paddingTop: "5px",
                                        position:"relative",
                                        borderRadius: " 20px ",
                                        fontFamily: 'Rowdies',
                                        // backgroundColor: "black",
                                        width: "223px",
                                        
                                      }}
                                    >
                                      {dt.contents}
                                      
                                     
                                      <p style={{fontSize:"10px",color:"white" , paddingLeft:"150px" }}>{moment(dt.createdAt).format('h:mm a')}</p> 
                                     
                                      </div>
                                  </div>
                                );
                              })}
                          </div>
                          
                        </div>

                        <div className="message-box">
                          <form
                            class="text-muted d-flex justify-content-start align-items-center pe-3 pt-3 mt-2"
                            onSubmit={sendMessage}
                          >
                            <input
                              type="text"
                              class="form-control form-control-lg"
                              id="exampleFormControlInput2"
                              placeholder="Type message"
                              name="messageBox"
                              value={chat}
                              // onChange={(e) => setChat(e.target.value)}
                              onChange = {inputHandler}
                              style={{
                                marginBottom: "15px",
                                marginLeft: "10px",
                                borderRadius: "20px",
                              }}
                            />
                            <button
                              class="btn btn-primary send-message-button"
                              type="submit"
                              style={{
                                marginBottom: "18px",
                                borderRadius: "20px",
                                marginLeft: "10px",
                              }}
                            >
                              {" "}
                              send
                            </button>
                          </form>
                        </div>
                      </div>
                   
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"></script>
    </div>
  );
}

export default NewChat;
