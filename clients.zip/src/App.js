import "./App.css";
import Login from "./Components/Login";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Chat from "./Components/Chat";
import Signup from "./Components/Signup";
import NewChat from "./Components/NewChat";


function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />}/>
          <Route path="/Signup" element={<Signup />}/>
         
            <Route path="/chat" element={<Chat />} />
            <Route path="/newchat" element={<NewChat />} />

        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
