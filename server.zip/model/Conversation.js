const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require("../database/db");



const ConversationModel = sequelize.define('chatapp_ConversationModel', {
    // Model attributes are defined here
    name: {
        type: DataTypes.STRING,
        defaultValue:"chat"
    },
    isGroupChat:{
        type: DataTypes.STRING,
        defaultValue:false
    },
});
module.exports = ConversationModel;