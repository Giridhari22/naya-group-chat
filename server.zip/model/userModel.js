const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require("../database/db");



const UserModel = sequelize.define('chatapp_userModel', {
    // Model attributes are defined here
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false,

    },
});
module.exports = UserModel;