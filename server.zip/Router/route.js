const router = require('express').Router();
const { signup, login , getAllUsers } = require("../Controllers/userController")

router.post("/signup", signup)
router.post("/login", login)
router.get("/getUsers", getAllUsers)



module.exports = router;